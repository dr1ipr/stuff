# Copyright (c) 2003-2016 CORE Security Technologies
#
# This software is provided under under a slightly modified version
# of the Apache Software License. See the accompanying LICENSE file
# for more information.
#

VER_MAJOR = "0"
VER_MINOR = "9.18-dev"

BANNER = "Impacket v%s.%s - Copyright 2002-2018 Core Security Technologies\n" % (VER_MAJOR,VER_MINOR)

